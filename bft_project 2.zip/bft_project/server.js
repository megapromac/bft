
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const eventsFilePath = path.join(__dirname, 'events.json');

app.get('/events', (req, res) => {
    fs.readFile(eventsFilePath, 'utf8', (err, data) => {
        if (err) return res.status(500).json([]);
        try {
            const parsed = JSON.parse(data);
            res.json(parsed.events || []);
        } catch {
            res.json([]);
        }
    });
});

app.post('/events', (req, res) => {
    const events = req.body.events;
    fs.writeFile(eventsFilePath, JSON.stringify({ events }, null, 2), (err) => {
        if (err) return res.status(500).json({ message: 'Ошибка записи' });
        res.json({ message: 'Сохранено' });
    });
});

app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});
