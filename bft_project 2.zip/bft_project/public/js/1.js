let emptyMessage = document.getElementById('emptyMessage');
let eventList = document.getElementById('eventList');
let events = [];
let isAdmin = false;

// Загрузка мероприятий с сервера
fetch('/events')
    .then(response => response.json())
    .then(data => {
        events = data.events || [];
        updateEventList();
    })
    .catch(error => {
        console.error('Ошибка при загрузке мероприятий:', error);
    });

// Проверка пароля
document.getElementById('loginButton').onclick = function () {
    const password = prompt('Введите пароль');

    if (password === '1111') {
        isAdmin = true;
        document.getElementById('adminName').textContent = 'Селицкий Ярослав';
        document.getElementById('adminName').style.display = 'block';
        document.getElementById('createEventButton').style.display = 'block';
        document.getElementById('loginButton').style.display = 'none';
    } else {
        alert('Неверный пароль');
    }
    updateEventList();
};

// Показать форму создания мероприятия
document.getElementById('createEventButton').onclick = function () {
    document.getElementById('eventForm').style.display = 'block';
};

// Добавление мероприятия
document.getElementById('eventForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const title = document.getElementById('title').value.trim();
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const city = document.getElementById('city').value.trim();
    const maxParticipants = document.getElementById('maxParticipants').value;

    if (!title || !startDate || !endDate || !city || !maxParticipants) {
        alert('Все поля должны быть заполнены.');
        return;
    }

    const eventObj = {
        title,
        startDate,
        endDate,
        city,
        maxParticipants,
        participants: 0,
        startDateTime: new Date(startDate),
        endDateTime: new Date(endDate),
        attendees: []
    };

    events.push(eventObj);
    saveEvents();
    events.sort((a, b) => a.startDateTime - b.startDateTime);
    updateEventList();

    document.getElementById('eventForm').reset();
    document.getElementById('eventForm').style.display = 'none';
    alert('Мероприятие успешно добавлено!');
});

// Сохраняем события на сервер
function saveEvents() {
    fetch('/events', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ events }),
    })
        .then(response => response.json())
        .then(data => {
            console.log('Сохранено:', data.message);
        })
        .catch(error => {
            console.error('Ошибка сохранения:', error);
        });
}

// Обновление списка мероприятий
function updateEventList() {
    eventList.innerHTML = '';
    emptyMessage.style.display = events.length === 0 ? 'block' : 'none';

    events.forEach((event, index) => {
        const eventBlock = document.createElement('div');
        eventBlock.classList.add('event-block');

        const formattedDate = `${formatDate(event.startDate)}-${formatDate(event.endDate)}`;

        eventBlock.innerHTML = `
            <div class="event-date">${formattedDate}</div>
            <div class="event-info">
                <h3>${event.title}</h3>
                <h3>${event.city}</h3>
                <span>${event.participants}/${event.maxParticipants}</span>
            </div>
        `;

        const withdrawButton = document.createElement('button');
        withdrawButton.textContent = 'Отозваться';
        withdrawButton.onclick = () => withdrawFromEvent(event, index);
        eventBlock.appendChild(withdrawButton);

        const listButton = document.createElement('button');
        listButton.textContent = 'Список';
        listButton.onclick = () => showAttendees(event);
        eventBlock.appendChild(listButton);

        if (isAdmin) {
            const editButton = document.createElement('button');
            editButton.textContent = 'Редактировать';
            editButton.onclick = () => editEvent(index);
            eventBlock.appendChild(editButton);

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Удалить';
            deleteButton.onclick = () => confirmDeleteEvent(index);
            eventBlock.appendChild(deleteButton);
        }

        eventList.appendChild(eventBlock);
    });
}

// Отозваться
function withdrawFromEvent(event, index) {
    if (event.attendees && event.attendees.includes('user')) {
        alert('Вы уже отозвались на это мероприятие!');
        return;
    }

    event.attendees.push('user');
    event.participants++;
    saveEvents();
    updateEventList();
    alert('Вы успешно отозвались на мероприятие!');
}

// Показать список судей
function showAttendees(event) {
    const modal = document.getElementById('judgesListModal');
    const eventTitle = document.getElementById('eventTitle');
    const judgesList = document.getElementById('judgesList');

    judgesList.innerHTML = '';
    eventTitle.textContent = event.title;

    if (event.attendees.length > 0) {
        event.attendees.forEach(judge => {
            const li = document.createElement('li');
            li.textContent = judge;
            judgesList.appendChild(li);
        });
    } else {
        const li = document.createElement('li');
        li.textContent = 'Нет судей, отозвавшихся на мероприятие.';
        judgesList.appendChild(li);
    }

    modal.style.display = 'block';
}

document.getElementById('closeModal').onclick = function () {
    document.getElementById('judgesListModal').style.display = 'none';
};

window.onclick = function (event) {
    if (event.target === document.getElementById('judgesListModal')) {
        document.getElementById('judgesListModal').style.display = 'none';
    }
};

// Редактирование мероприятия
function editEvent(index) {
    const event = events[index];
    document.getElementById('title').value = event.title;
    document.getElementById('startDate').value = event.startDate;
    document.getElementById('endDate').value = event.endDate;
    document.getElementById('city').value = event.city;
    document.getElementById('maxParticipants').value = event.maxParticipants;
    deleteEvent(index);
}

// Удаление мероприятия
function confirmDeleteEvent(index) {
    if (confirm('Вы уверены, что хотите удалить это мероприятие?')) {
        deleteEvent(index);
    }
}

function deleteEvent(index) {
    events.splice(index, 1);
    saveEvents();
    updateEventList();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    return `${day}.${month}`;
}
