let emptyMessage = document.getElementById('emptyMessage');
let eventList = document.getElementById('eventList');
let events = [];
let isAdmin = false;

// Загрузка мероприятий с сервера
async function fetchEvents() {
    const response = await fetch('/events');
    events = await response.json();
    events.sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
    updateEventList();
}

// Сохранение мероприятий на сервер
async function saveEvents() {
    await fetch('/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events })
    });
}

document.getElementById('loginButton').onclick = function () {
    const password = prompt('Введите пароль');
    if (password === '1111') {
        isAdmin = true;
        document.getElementById('adminName').textContent = 'Селицкий Ярослав';
        document.getElementById('adminName').style.display = 'block';
        document.getElementById('createEventButton').style.display = 'block';
        document.getElementById('loginButton').style.display = 'none';
    } else {
        alert('Неверный пароль');
    }
    updateEventList();
};

document.getElementById('createEventButton').onclick = function () {
    document.getElementById('eventForm').style.display = 'block';
};

document.getElementById('eventForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const title = document.getElementById('title').value.trim();
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const city = document.getElementById('city').value.trim();
    const maxParticipants = document.getElementById('maxParticipants').value;

    if (!title || !startDate || !endDate || !maxParticipants || !city) {
        alert('Все поля должны быть заполнены.');
        return;
    }

    const eventObj = {
        title,
        startDate,
        endDate,
        city,
        maxParticipants,
        participants: 0,
        attendees: []
    };

    events.push(eventObj);
    await saveEvents();
    await fetchEvents();

    document.getElementById('eventForm').reset();
    document.getElementById('eventForm').style.display = 'none';
    alert('Мероприятие успешно добавлено!');
});

function updateEventList() {
    eventList.innerHTML = '';
    emptyMessage.style.display = 'none';

    if (events.length === 0) {
        emptyMessage.style.display = 'block';
        return;
    }

    events.forEach((event, index) => {
        const eventBlock = document.createElement('div');
        eventBlock.classList.add('event-block');

        const formattedDate = `${formatDate(event.startDate)}-${formatDate(event.endDate)}`;

        eventBlock.innerHTML = `
            <div class="event-date">${formattedDate}</div>
            <div class="event-info">
                <h3>${event.title}</h3>
                <h3>${event.city}</h3>
                <span>${event.participants}/${event.maxParticipants}</span>
            </div>
        `;

        const respondButton = document.createElement('button');
        respondButton.textContent = 'Отозваться';
        respondButton.onclick = async () => {
            if (!event.attendees.includes('user')) {
                event.attendees.push('user');
                event.participants++;
                await saveEvents();
                updateEventList();
                alert('Вы успешно отозвались!');
            } else {
                alert('Вы уже отозвались на это мероприятие!');
            }
        };
        eventBlock.appendChild(respondButton);

        const listButton = document.createElement('button');
        listButton.textContent = 'Список';
        listButton.onclick = () => showAttendees(event);
        eventBlock.appendChild(listButton);

        if (isAdmin) {
            const editButton = document.createElement('button');
            editButton.textContent = 'Редактировать';
            editButton.onclick = () => editEvent(index);
            eventBlock.appendChild(editButton);

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Удалить';
            deleteButton.onclick = async () => {
                if (confirm('Удалить мероприятие?')) {
                    events.splice(index, 1);
                    await saveEvents();
                    updateEventList();
                }
            };
            eventBlock.appendChild(deleteButton);
        }

        eventList.appendChild(eventBlock);
    });
}

function showAttendees(event) {
    const modal = document.getElementById('judgesListModal');
    const eventTitle = document.getElementById('eventTitle');
    const judgesList = document.getElementById('judgesList');

    judgesList.innerHTML = '';
    eventTitle.textContent = event.title;

    if (event.attendees.length > 0) {
        event.attendees.forEach(judge => {
            const item = document.createElement('li');
            item.textContent = judge;
            judgesList.appendChild(item);
        });
    } else {
        const empty = document.createElement('li');
        empty.textContent = 'Нет судей.';
        judgesList.appendChild(empty);
    }

    modal.style.display = 'block';
}

document.getElementById('closeModal').onclick = function () {
    document.getElementById('judgesListModal').style.display = 'none';
};

window.onclick = function (event) {
    if (event.target === document.getElementById('judgesListModal')) {
        document.getElementById('judgesListModal').style.display = 'none';
    }
};

function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    return `${day}.${month}`;
}

// Загружаем мероприятия при старте
window.onload = fetchEvents;
